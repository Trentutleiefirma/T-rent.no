<?php
/**
 * Customer processing order email
 *
 * @package WooCommerce\Templates\Emails
 * @version 10.4.0
 */
use Automattic\WooCommerce\Utilities\FeaturesUtil;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$email_improvements_enabled = FeaturesUtil::feature_is_enabled( 'email_improvements' );

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php echo $email_improvements_enabled ? '<div class="email-introduction">' : ''; ?>
<p>
<?php
if ( ! empty( $order->get_billing_first_name() ) ) {
	printf( esc_html( 'Hei %s,' ), esc_html( $order->get_billing_first_name() ) );
} else {
	echo esc_html( 'Hei,' );
}
?>
</p>
<p><?php echo esc_html( 'Her er en oversikt over din bestilling:' ); ?></p>
<?php echo $email_improvements_enabled ? '</div>' : ''; ?>

<div style="margin:20px 0;padding:15px;background:#f7f7f7;border-left:4px solid #333;">
	<p style="margin:0 0 4px 0;"><strong>Levering:</strong></p>
	<p style="margin:0 0 14px 0;">Senest kl 20 siste dagen, om ikke annet er avtalt.</p>

	<p style="margin:0 0 4px 0;"><strong>Brukerinformasjon:</strong></p>
	<p style="margin:0 0 14px 0;">Du finner brukerinformasjon og tips til utstyret lenger ned i denne e-posten.</p>

	<p style="margin:0 0 4px 0;"><strong>Kontakt oss:</strong></p>
	<p style="margin:0 0 14px 0;">
		Adresse: <a href="https://maps.app.goo.gl/SGGrLyovcMW5RNvH6">https://maps.app.goo.gl/SGGrLyovcMW5RNvH6</a><br>
		Tele: 92072993
	</p>

	<p style="margin:0 0 4px 0;"><strong>Åpningstider:</strong></p>
	<p style="margin:0;">
		Mon-fre 8:00-20:00<br>
		Lør-søn 9:00-20:00
	</p>
</div>

<?php
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );
do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );
do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

if ( $additional_content ) {
	echo $email_improvements_enabled ? '<table border="0" cellpadding="0" cellspacing="0" width="100%" role="presentation"><tr><td class="email-additional-content">' : '';
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
	echo $email_improvements_enabled ? '</td></tr></table>' : '';
}

do_action( 'woocommerce_email_footer', $email );